package com.saisanket.ecm_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
